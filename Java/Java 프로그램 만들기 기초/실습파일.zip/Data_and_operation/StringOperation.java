
public class StringOperation {

	public static void main(String[] args) {
		
		System.out.println("Hello World".length()); // 11
		System.out.println("Hello, [[[name]]] ... bye. ".replace("[[[name]]]", "duru"));

	}

}
