
public class Letter {

	public static void main(String[] args) {
		String name = "leezche";
		System.out.println("Hello, "+name+" ... "+name+" ... egoing ... bye");
		
		double VAT = 10.0;
		System.out.println(VAT);
	}

}
